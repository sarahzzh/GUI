/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.loginregister;

/**
 *
 * @author A
 */
public class Logindanreg {
   public static void main(String[] args){
       register reg = new register();
       reg.setVisible(true);
       reg.pack();
       reg.setLocationRelativeTo(null);
       reg.setDefaultCloseOperation(register.EXIT_ON_CLOSE);
   }
    
}
